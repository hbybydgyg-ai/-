<?php
require dirname(__DIR__) . '/_common.php';
$path = dirname(__DIR__, 2) . '/data/providers.json';
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $data = read_json_file($path, ['activeProvider'=>'','providers'=>[]]);
    // Never expose API keys through GET.
    $safe=[];
    foreach (($data['providers'] ?? []) as $id=>$p) {
        $safe[$id]=['id'=>$id,'name'=>$p['name'] ?? $id,'url'=>$p['url'] ?? ''];
    }
    json_out(['activeProvider'=>$data['activeProvider'] ?? '', 'providers'=>$safe]);
}
if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !is_admin()) json_out(['error'=>'غير مصرح'],403);
$in = input_json();
$providers = $in['providers'] ?? [];
$active = trim((string)($in['activeProvider'] ?? ''));
if (!is_array($providers)) json_out(['error'=>'بيانات المزودين غير صحيحة'],422);
$out=[];
foreach ($providers as $p) {
    if (!is_array($p)) continue;
    $id = preg_replace('/[^a-zA-Z0-9_-]/','', (string)($p['id'] ?? ''));
    $name = trim((string)($p['name'] ?? ''));
    $url = trim((string)($p['url'] ?? ''));
    $key = trim((string)($p['key'] ?? ''));
    if (!$id || !$name || !$url || !$key) continue;
    if (!preg_match('#^https?://#i',$url)) continue;
    $out[$id]=['name'=>$name,'url'=>$url,'key'=>$key];
}
write_json_file($path,['activeProvider'=>$active,'providers'=>$out,'updatedAt'=>gmdate('c')]);
json_out(['ok'=>true,'count'=>count($out)]);
