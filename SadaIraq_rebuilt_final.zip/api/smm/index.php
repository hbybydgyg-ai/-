<?php
require dirname(__DIR__) . '/_common.php';
$path = dirname(__DIR__, 2) . '/data/providers.json';
$store = read_json_file($path, ['activeProvider'=>'','providers'=>[]]);
$providerId = trim((string)($_GET['provider'] ?? $store['activeProvider'] ?? ''));
$provider = $store['providers'][$providerId] ?? null;

// Temporary URL/key is accepted only for an authenticated admin connection test.
if (!$provider && is_admin()) {
    $u = trim((string)($_GET['_url'] ?? ''));
    $k = trim((string)($_GET['_key'] ?? ''));
    if ($u && $k && preg_match('#^https?://#i',$u)) $provider=['name'=>'اختبار','url'=>$u,'key'=>$k];
}
if (!$provider) json_out(['error'=>'لا يوجد مزود محفوظ. أضف المزود من لوحة الإدارة أولاً.'],404);

$action = trim((string)($_GET['action'] ?? 'balance'));
$allowed = ['balance','services','add','status'];
if (!in_array($action,$allowed,true)) json_out(['error'=>'عملية غير مدعومة'],422);
$params=[];
foreach (['service','link','quantity','order'] as $k) if (isset($_GET[$k])) $params[$k]=(string)$_GET[$k];
$params['key']=$provider['key'];
$params['action']=$action;

try {
    // SMM API v2 convention: POST form-encoded to the exact API URL provided by the admin.
    $data = request_form_post($provider['url'], ['Content-Type'=>'application/x-www-form-urlencoded; charset=UTF-8','Accept'=>'application/json'], $params, 35);
    json_out($data);
} catch (Throwable $e) {
    json_out(['error'=>$e->getMessage()],502);
}
