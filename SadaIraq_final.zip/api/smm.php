<?php
/** صدى العراق - بوابة اتصال مزودي SMM */
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate');
function out($data, $status = 200) {
    http_response_code($status);
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}
if (!in_array($_SERVER['REQUEST_METHOD'] ?? '', ['GET','POST'], true)) out(['error'=>'طريقة الطلب غير مدعومة'],405);
$src = ($_SERVER['REQUEST_METHOD'] === 'POST') ? $_POST : $_GET;
$action = trim((string)($src['action'] ?? ''));
$url = trim((string)($src['_url'] ?? ''));
$key = trim((string)($src['_key'] ?? ''));
if ($url === '' || $key === '') out(['error'=>'بيانات المزود ناقصة: رابط API ومفتاح API مطلوبان'],400);
if (!filter_var($url, FILTER_VALIDATE_URL)) out(['error'=>'رابط API غير صالح'],400);
$parts = parse_url($url);
if (!$parts || !in_array(strtolower($parts['scheme'] ?? ''), ['http','https'], true)) out(['error'=>'رابط API يجب أن يبدأ بـ http أو https'],400);
if ($action === '') out(['error'=>'لم يتم تحديد العملية'],400);
$payload = [];
foreach ($src as $k => $v) {
    if ($k === '_url' || $k === '_key' || $k === 'provider') continue;
    $payload[$k] = is_string($v) ? trim($v) : $v;
}
$payload['key'] = $key;
$payload['action'] = $action;
$raw = false;
$status = 0;
if (function_exists('curl_init')) {
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => http_build_query($payload, '', '&'),
        CURLOPT_CONNECTTIMEOUT => 12,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_MAXREDIRS => 4,
        CURLOPT_SSL_VERIFYPEER => true,
        CURLOPT_SSL_VERIFYHOST => 2,
        CURLOPT_HTTPHEADER => [
            'Accept: application/json, text/plain, */*',
            'Content-Type: application/x-www-form-urlencoded; charset=UTF-8'
        ],
        CURLOPT_USERAGENT => 'SadaIraq-SMM/1.0'
    ]);
    $raw = curl_exec($ch);
    $errno = curl_errno($ch);
    $error = curl_error($ch);
    $status = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    if ($errno) out(['error'=>'فشل الاتصال بالمزود: '.$error],502);
} else {
    if (!ini_get('allow_url_fopen')) out(['error'=>'الاستضافة لا توفر cURL ولا allow_url_fopen، يجب تفعيل cURL'],500);
    $headers = "Content-Type: application/x-www-form-urlencoded\r\n" .
               "Accept: application/json, text/plain, */*\r\n" .
               "User-Agent: SadaIraq-SMM/1.0\r\n";
    $context = stream_context_create([
        'http' => [
            'method' => 'POST',
            'header' => $headers,
            'content' => http_build_query($payload, '', '&'),
            'timeout' => 30,
            'ignore_errors' => true
        ],
        'ssl' => ['verify_peer'=>true,'verify_peer_name'=>true]
    ]);
    $raw = @file_get_contents($url, false, $context);
    foreach (($http_response_header ?? []) as $h) {
        if (preg_match('/^HTTP\/\S+\s+(\d+)/i', $h, $m)) { $status=(int)$m[1]; break; }
    }
    if ($raw === false) out(['error'=>'تعذر الاتصال بالمزود من الخادم'],502);
}
if ($status < 200 || $status >= 300) {
    $short = trim(strip_tags((string)$raw));
    if (strlen($short)>300) $short=substr($short,0,300).'...';
    out(['error'=>'المزود أعاد HTTP '.$status.($short!==''?': '.$short:'')],502);
}
$decoded = json_decode((string)$raw, true);
if (json_last_error() === JSON_ERROR_NONE) out($decoded);
$trimmed = trim((string)$raw);
if ($trimmed !== '') out(['error'=>'استجابة المزود ليست JSON صالحاً','raw'=>substr($trimmed,0,500)],502);
out(['error'=>'المزود أعاد استجابة فارغة'],502);
