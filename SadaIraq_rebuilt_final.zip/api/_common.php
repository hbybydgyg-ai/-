<?php
// Sada Iraq API common helpers
session_name('sadairaq_sid');
session_set_cookie_params([
    'httponly' => true,
    'samesite' => 'Lax',
    'secure'   => (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off'),
]);
session_start();
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');

function json_out($data, int $status = 200): void {
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function input_json(): array {
    $raw = file_get_contents('php://input');
    if (!$raw) return [];
    $data = json_decode($raw, true);
    return is_array($data) ? $data : [];
}

function is_admin(): bool {
    return !empty($_SESSION['sadairaq_admin']);
}

function clean_phone(string $text): ?string {
    $phone = preg_replace('/\D+/', '', $text);
    if (str_starts_with($phone, '00964')) $phone = '0' . substr($phone, 5);
    if (str_starts_with($phone, '964')) $phone = '0' . substr($phone, 3);
    return preg_match('/^07\d{9}$/', $phone) ? $phone : null;
}

function http_post_raw(string $url, array $headers, string $payload, int $timeout = 30): array {
    if (!preg_match('#^https?://#i', $url)) throw new RuntimeException('رابط API غير صالح');
    $headerList = [];
    foreach ($headers as $k => $v) $headerList[] = $k . ': ' . $v;
    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        if (!$ch) throw new RuntimeException('تعذر إنشاء اتصال cURL');
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $payload,
            CURLOPT_HTTPHEADER => $headerList,
            CURLOPT_CONNECTTIMEOUT => 12,
            CURLOPT_TIMEOUT => $timeout,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_MAXREDIRS => 3,
            CURLOPT_ENCODING => '',
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
        ]);
        $body = curl_exec($ch);
        $errno = curl_errno($ch);
        $err = curl_error($ch);
        $status = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
        curl_close($ch);
        if ($errno) throw new RuntimeException('فشل الاتصال: ' . $err);
        return [$body, $status];
    }
    $context = stream_context_create(['http'=>[
        'method'=>'POST','header'=>implode("\r\n",$headerList),'content'=>$payload,
        'timeout'=>$timeout,'ignore_errors'=>true,
    ],'ssl'=>['verify_peer'=>true,'verify_peer_name'=>true]]);
    $body=@file_get_contents($url,false,$context);
    if ($body===false) throw new RuntimeException('تعذر الاتصال بخادم API');
    $status=200;
    foreach (($http_response_header ?? []) as $h) if (preg_match('#^HTTP/\S+\s+(\d+)#',$h,$m)) {$status=(int)$m[1]; break;}
    return [$body,$status];
}

function request_json_post(string $url, array $headers, array $payload, int $timeout = 30): array {
    [$body,$status] = http_post_raw($url,$headers,json_encode($payload,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),$timeout);
    $data = json_decode((string)$body,true);
    if (!is_array($data)) throw new RuntimeException('استجابة غير مفهومة من API (HTTP '.$status.')');
    if ($status >= 400) { $msg=$data['message']??$data['error']??('HTTP '.$status); throw new RuntimeException((string)$msg); }
    return $data;
}

function request_form_post(string $url, array $headers, array $payload, int $timeout = 30): array {
    $headers['Content-Type'] = $headers['Content-Type'] ?? 'application/x-www-form-urlencoded; charset=UTF-8';
    [$body,$status] = http_post_raw($url,$headers,http_build_query($payload),$timeout);
    $data = json_decode((string)$body,true);
    if (!is_array($data)) throw new RuntimeException('استجابة غير مفهومة من API (HTTP '.$status.')');
    if ($status >= 400) { $msg=$data['message']??$data['error']??('HTTP '.$status); throw new RuntimeException((string)$msg); }
    return $data;
}

function read_json_file(string $path, array $default = []): array {
    if (!is_file($path)) return $default;
    $raw = file_get_contents($path);
    $data = json_decode($raw ?: '', true);
    return is_array($data) ? $data : $default;
}

function write_json_file(string $path, array $data): void {
    $dir = dirname($path);
    if (!is_dir($dir) && !mkdir($dir, 0775, true)) throw new RuntimeException('تعذر إنشاء مجلد البيانات');
    $tmp = $path . '.tmp';
    $json = json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
    if (file_put_contents($tmp, $json, LOCK_EX) === false) throw new RuntimeException('تعذر كتابة البيانات');
    if (!rename($tmp, $path)) throw new RuntimeException('تعذر حفظ البيانات');
}
