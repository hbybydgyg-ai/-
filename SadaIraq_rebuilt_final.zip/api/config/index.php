<?php
require dirname(__DIR__) . '/_common.php';
// Public configuration only. No old admin credentials and no provider keys are returned.
json_out([
  'appName' => 'صدى العراق',
  'currency' => 'USD',
  'exchangeRate' => 1250,
  'note' => '1 USD = 1,250 IQD'
]);
