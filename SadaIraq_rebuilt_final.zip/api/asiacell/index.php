<?php
require dirname(__DIR__) . '/_common.php';
if ($_SERVER['REQUEST_METHOD'] !== 'POST') json_out(['error'=>'الطريقة غير مسموحة'],405);
$in = input_json();
$action = (string)($in['action'] ?? '');
$FIXED_RECEIVER = '07763308188';

function ac_headers(): array {
    $apiKey = bin2hex(random_bytes(16));
    $device = sprintf('%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
        random_int(0,0xffff), random_int(0,0xffff), random_int(0,0xffff),
        random_int(0,0x0fff)|0x4000, random_int(0,0x3fff)|0x8000,
        random_int(0,0xffff), random_int(0,0xffff), random_int(0,0xffff));
    return [
        'User-Agent' => 'okhttp/5.0.0-alpha.2',
        'Connection' => 'Keep-Alive',
        'Accept-Encoding' => 'gzip',
        'X-ODP-API-KEY' => $apiKey,
        'DeviceID' => $device,
        'X-OS-Version' => '11',
        'X-Device-Type' => '[Android]',
        'X-ODP-APP-VERSION' => '4.3.7',
        'X-FROM-APP' => 'odp',
        'X-ODP-CHANNEL' => 'mobile',
        'Content-Type' => 'application/json; charset=UTF-8',
    ];
}
function ac_session(): array { return is_array($_SESSION['asiacell'] ?? null) ? $_SESSION['asiacell'] : []; }
function ac_save(array $s): void { $_SESSION['asiacell']=$s; }
function ac_require_session(): array { $s=ac_session(); if (!$s) json_out(['error'=>'جلسة آسياسيل منتهية، ابدأ من جديد'],409); return $s; }

try {
    if ($action === 'login') {
        $phone = clean_phone((string)($in['phone'] ?? ''));
        if (!$phone) json_out(['error'=>'رقم آسياسيل غير صحيح. استخدم 077xxxxxxxx'],422);
        $headers = ac_headers();
        $data = request_json_post('https://odpapp.asiacell.com/api/v1/login?lang=en', $headers, ['captchaCode'=>'','username'=>$phone], 30);
        $nextUrl = (string)($data['nextUrl'] ?? '');
        if (!preg_match('/PID=([a-f0-9-]+)/i', $nextUrl, $m)) {
            $message=(string)($data['message'] ?? 'فشل إرسال رمز SMS');
            throw new RuntimeException($message);
        }
        ac_save(['phone'=>$phone,'headers'=>$headers,'pid'=>$m[1],'step'=>'sms','createdAt'=>time()]);
        json_out(['ok'=>true,'message'=>'تم إرسال رمز SMS إلى الرقم.']);
    }

    if ($action === 'verify_sms') {
        $s = ac_require_session();
        if (($s['step'] ?? '') !== 'sms') json_out(['error'=>'الخطوة غير صحيحة'],409);
        $code = trim((string)($in['passcode'] ?? ''));
        if ($code === '' || !preg_match('/^\d{4,8}$/',$code)) json_out(['error'=>'رمز SMS غير صحيح'],422);
        $data = request_json_post('https://odpapp.asiacell.com/api/v1/smsvalidation?lang=en', $s['headers'], ['PID'=>$s['pid'],'passcode'=>$code,'token'=>''], 30);
        if (empty($data['success']) || empty($data['access_token'])) {
            throw new RuntimeException((string)($data['message'] ?? 'رمز SMS غير صحيح'));
        }
        $s['headers']['Authorization']='Bearer '.$data['access_token'];
        $s['step']='amount'; ac_save($s);
        json_out(['ok'=>true,'message'=>'تم التحقق من الخط بنجاح.']);
    }

    if ($action === 'start_transfer') {
        $s = ac_require_session();
        if (($s['step'] ?? '') !== 'amount') json_out(['error'=>'تحقق من رقم الهاتف أولاً'],409);
        $amount = (int)($in['amount'] ?? 0);
        if ($amount < 1000 || $amount > 10000 || $amount % 1000 !== 0) {
            json_out(['error'=>'المبلغ يجب أن يكون من 1,000 إلى 10,000 دينار وبمضاعفات 1,000'],422);
        }
        $data = request_json_post('https://odpapp.asiacell.com/api/v1/credit-transfer/start?lang=ar', $s['headers'], ['amount'=>$amount,'receiverMsisdn'=>$FIXED_RECEIVER], 30);
        if (empty($data['PID'])) throw new RuntimeException((string)($data['message'] ?? 'فشل بدء التحويل'));
        $s['pid_transfer']=(string)$data['PID']; $s['amount']=$amount; $s['step']='transfer_sms'; ac_save($s);
        json_out(['ok'=>true,'message'=>'تم إرسال رمز تأكيد التحويل.','usd'=>$amount/1250,'receiver'=>$FIXED_RECEIVER]);
    }

    if ($action === 'confirm_transfer') {
        $s = ac_require_session();
        if (($s['step'] ?? '') !== 'transfer_sms' || empty($s['pid_transfer'])) json_out(['error'=>'لا توجد عملية تحويل قيد التأكيد'],409);
        $code = trim((string)($in['passcode'] ?? ''));
        if ($code === '' || !preg_match('/^\d{4,8}$/',$code)) json_out(['error'=>'رمز التحويل غير صحيح'],422);
        $data = request_json_post('https://odpapp.asiacell.com/api/v1/credit-transfer/do-transfer?lang=ar', $s['headers'], ['PID'=>$s['pid_transfer'],'passcode'=>$code], 30);
        if (empty($data['success'])) throw new RuntimeException((string)($data['message'] ?? 'فشل التحويل'));
        $amount=(int)($s['amount'] ?? 0); $phone=(string)($s['phone'] ?? '');
        // Keep result server-side long enough to prevent accidental duplicate confirmation in the same session.
        $s['step']='completed'; $s['completedAt']=time(); $s['resultPid']=(string)$s['pid_transfer']; ac_save($s);
        json_out(['ok'=>true,'message'=>'تم التحويل بنجاح','usd'=>$amount/1250,'amountIQD'=>$amount,'receiver'=>$FIXED_RECEIVER,'phone'=>$phone,'transferPid'=>(string)$s['pid_transfer']]);
    }

    if ($action === 'reset') { unset($_SESSION['asiacell']); json_out(['ok'=>true]); }
    json_out(['error'=>'عملية غير معروفة'],422);
} catch (Throwable $e) {
    json_out(['error'=>$e->getMessage()],502);
}
