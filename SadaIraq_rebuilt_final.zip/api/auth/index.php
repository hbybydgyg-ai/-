<?php
require dirname(__DIR__) . '/_common.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') json_out(['error'=>'الطريقة غير مسموحة'],405);
$in = input_json();
$username = trim((string)($in['username'] ?? ''));
$password = (string)($in['password'] ?? '');
$adminUser = 'hsydgyg5@gmail.com';
$adminHash = '$2y$12$h/gtmzAmF9ibjxmEcZo1yes2/acITIkqSsZ4v5v1t0VXqsvq7g3xa';
if ($username === $adminUser && password_verify($password, $adminHash)) {
    session_regenerate_id(true);
    $_SESSION['sadairaq_admin'] = true;
    $_SESSION['sadairaq_admin_user'] = $adminUser;
    json_out(['ok'=>true,'role'=>'admin','username'=>$adminUser]);
}
$_SESSION['sadairaq_admin'] = false;
json_out(['ok'=>false,'error'=>'بيانات الدخول غير صحيحة'],401);
